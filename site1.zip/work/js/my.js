$('.our-work .box').css({'height':$('.our-work .box').width()+'px'});
window.onresize = function(){ 
	$('.our-work .box').css({'height':$('.our-work .box').width()+'px'});
}